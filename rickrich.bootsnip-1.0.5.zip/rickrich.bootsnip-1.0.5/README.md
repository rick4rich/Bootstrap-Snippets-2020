# About Bootstrap-extension
Bootstrap Snippets 2020 is extension that have snippets on bootstrap.

## Features

So many components of bootsrap 4.5 along with additional snippets.If you are a web-designer it really supports for you.Happy Coding!


<!-- video -->

-   How to start using Bootstrap snippets 2020 😀

     <img src= https://www.rickrich.co/bootsnip/bootstart.png>


## Tips

 Tip:All snippets is starting with boot:

 Tip:If you are starting project including bootstrap  use "boot:start"

## Requirements
You should have a basic knowledge on Html,css,javascript and Bootstrap 4.5
## Added Features Are
- Use This before starting
     * boot:start

     - Demo 
    <img src = https://www.rickrich.co/bootsnip/bootstart.png  > 
     
- Bootstrap btn
      * boot:btn-outline-sucess
      * boot:btn-outline-primary
      * boot:btn-link
      * boot:btn-dark
      * boot:btn-light
      * boot:btn-info
      * boot:btn-warning
      * boot:btn-danger
      * boot:btn-sucess
      * boot:btn-secondary
      * boot:btn-primary

- Bootstrap Jumbotron
      * boot:jumbotron

- Bootstrap File Input
      * boot:custom:file

- Bootstrap Input
      * boot:multiple:input
      * boot:input:group

- Bootstrap  File Input
      * boot:file:upload

- Bootstrap Forms
      * boot:forms

- Bootstrap Container Fluid
      * boot:container:fluid

- Bootstrap Text Selection
      * boot:text:selection

- Bootstrap Container Fluid
      * boot:grid

- and more                                              

## Working with Markdown

**Note:** You can author your README using Visual Studio Code.  Here are some useful editor keyboard shortcuts:

* Split the editor (`Cmd+\` on macOS or `Ctrl+\` on Windows and Linux)
* Toggle preview (`Shift+CMD+V` on macOS or `Shift+Ctrl+V` on Windows and Linux)
* Press `Ctrl+Space` (Windows, Linux) or `Cmd+Space` (macOS) to see a list of Markdown snippets

### For more information

* [Visual Studio Code's Markdown Support](http://code.visualstudio.com/docs/languages/markdown)
* [Markdown Syntax Reference](https://help.github.com/articles/markdown-basics/)

**Enjoy! using  Bootstrap snippets 2020**
